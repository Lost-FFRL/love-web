// JavaScript Document
var Dianji = 0;
window.onload = function () {
  var buhao = document.getElementById('buhao');
  var hao = document.getElementById('hao');
  var rejectTexts = [
    '能够遇见你，是我今生最大的幸福',
    '有了你，我的生活变的无限宽广!',
    '有了你，世界变得如此迷人!',
    '你是世界，世界是你!',
    '我愿意用自己的心，好好的陪着你，爱着你。',
    '你考虑一下呗',
  ];
  buhao.onclick = function () {
    for (var i = 0; i < rejectTexts.length; i++) {
      if (Dianji === i) {
        alert(rejectTexts[i]);
        Dianji++;
      }
      if (Dianji === rejectTexts.length - 1) {
        Dianji = 0;
      }
    }
  };
  hao.onclick = function () {
    alert('❤❤❤ 终于同意了，我爱你 ❤❤❤');
  };
};
